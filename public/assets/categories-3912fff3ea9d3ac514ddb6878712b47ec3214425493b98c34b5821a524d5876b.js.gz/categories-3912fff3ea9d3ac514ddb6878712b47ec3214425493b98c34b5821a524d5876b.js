(function() {
  $(function() {
    return $('.colorpicker').minicolors({
      theme: 'bootstrap'
    });
  });

}).call(this);
